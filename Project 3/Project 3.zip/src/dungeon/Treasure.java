package dungeon;

/**
 * This is used to store the fixed Treasure Values.
 */
public enum Treasure {
  DIAMOND,
  SAPPHIRE,
  RUBY
}
